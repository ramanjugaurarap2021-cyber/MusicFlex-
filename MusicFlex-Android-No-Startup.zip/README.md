# MusicFlex Android

Android Studio project wrapping the current MusicFlex v17 HTML prototype in a native WebView.

## Open
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run the `app` configuration on an Android device/emulator.

## Included
- Current MusicFlex v17 prototype as `app/src/main/assets/index.html`
- Supplied MusicFlex icon
- Native animated startup screen
- Hardware-accelerated WebView
- Android-safe status/navigation bar handling
- Reduced blur layer for WebView performance
- Reduced-motion support
- Android back handling for open sheets/player

This is a prototype shell. Real YouTube playback, authentication, downloads, background playback, media notification controls, and Android media-session integration should be added in the native implementation phase.
